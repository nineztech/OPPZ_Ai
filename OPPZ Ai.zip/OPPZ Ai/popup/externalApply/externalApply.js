// Initialize empty data array
let externalApplyData = [];

// Global DOM element references
let linksDiv = null;
let linksCountElement = null;

// Function to check if we're running in Chrome extension context
function isExtensionContext() {
	return typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
}

// Function to update the links counter
function updateLinksCounter(count) {
	if (linksCountElement) {
		linksCountElement.textContent = count;
	}
}

// Function to create and display a single job link row
function addLinkRow(job) {
	if (!linksDiv) return;
	
	const container = document.createElement('div');
	container.className = 'link-container';
	container.style.cssText = `
		border: 1px solid #ddd;
		border-radius: 8px;
		padding: 15px;
		margin: 10px 0;
		background-color: #fff;
		box-shadow: 0 2px 4px rgba(0,0,0,0.1);
	`;
	
	// Job title
	const title = document.createElement('div');
	title.className = 'job-title';
	title.style.cssText = `
		font-size: 18px;
		font-weight: bold;
		color: #333;
		margin-bottom: 8px;
	`;
	title.textContent = (job?.title ?? 'Untitled Job').trim();
	
	// Company and time wrapper
	const companyWrapper = document.createElement('div');
	companyWrapper.style.cssText = `
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 10px;
	`;
	
	// Format time
	let timeString = '';
	if (job?.time) {
		const date = new Date(job.time);
		const day = String(date.getDate()).padStart(2, '0');
		const month = String(date.getMonth() + 1).padStart(2, '0');
		const year = String(date.getFullYear()).slice(-2);
		const hour = String(date.getHours()).padStart(2, '0');
		const minute = String(date.getMinutes()).padStart(2, '0');
		timeString = `${day}/${month}/${year}, ${hour}:${minute}`;
	}
	
	const time = document.createElement('div');
	time.className = 'job-time';
	time.style.cssText = `
		font-size: 12px;
		color: #888;
		background-color: #f0f0f0;
		padding: 4px 8px;
		border-radius: 4px;
	`;
	time.textContent = timeString || 'No date';
	
	// Company name
	const company = document.createElement('div');
	company.className = 'company-name';
	company.style.cssText = `
		font-size: 14px;
		color: #555;
		font-weight: 500;
	`;
	company.textContent = `Company: ${(job?.companyName ?? 'Unknown Company').trim()}`;
	
	companyWrapper.appendChild(company);
	companyWrapper.appendChild(time);
	
	// Job link
	const linkWrapper = document.createElement('div');
	linkWrapper.style.cssText = `
		margin: 10px 0;
		padding: 8px;
		background-color: #f8f9fa;
		border-radius: 4px;
		word-break: break-all;
	`;
	
	const link = document.createElement('a');
	link.href = job.link || '#';
	link.textContent = job.link || 'No link available';
	link.target = '_blank';
	link.style.cssText = `
		color: #0066cc;
		text-decoration: none;
		font-size: 14px;
	`;
	link.addEventListener('mouseenter', () => {
		link.style.textDecoration = 'underline';
	});
	link.addEventListener('mouseleave', () => {
		link.style.textDecoration = 'none';
	});
	
	linkWrapper.appendChild(link);
	
	// Delete button
	const deleteBtn = document.createElement('button');
	deleteBtn.textContent = 'Delete';
	deleteBtn.style.cssText = `
		background-color: #dc3545;
		color: white;
		border: none;
		padding: 8px 16px;
		border-radius: 4px;
		cursor: pointer;
		font-size: 14px;
		margin-top: 10px;
	`;
	deleteBtn.addEventListener('mouseenter', () => {
		deleteBtn.style.backgroundColor = '#c82333';
	});
	deleteBtn.addEventListener('mouseleave', () => {
		deleteBtn.style.backgroundColor = '#dc3545';
	});
	deleteBtn.addEventListener('click', () => {
		if (confirm('Are you sure you want to delete this job link?')) {
			removeJob(job.link);
		}
	});
	
	// Assemble the container
	container.appendChild(title);
	container.appendChild(companyWrapper);
	container.appendChild(linkWrapper);
	container.appendChild(deleteBtn);
	linksDiv.appendChild(container);
}

// Function to load and display all jobs
function loadJobs() {
	console.log('Loading jobs, count:', externalApplyData.length);
	
	if (!linksDiv) {
		console.error('linksDiv not available yet, will retry when DOM is ready');
		return;
	}
	
	linksDiv.innerHTML = '';
	
	if (externalApplyData.length === 0) {
		const noJobsMsg = document.createElement('div');
		noJobsMsg.id = 'no-jobs-message';
		noJobsMsg.style.cssText = `
			text-align: center;
			padding: 40px 20px;
			color: #666;
			font-size: 16px;
			background-color: #f8f9fa;
			border-radius: 8px;
			margin: 20px 0;
		`;
		
		if (isExtensionContext()) {
			noJobsMsg.innerHTML = `
				<p>No job links saved yet.</p>
				<p>Start auto-applying on LinkedIn and your external apply jobs will appear here!</p>
				<p>Or add jobs manually using the form above.</p>
			`;
		} else {
			noJobsMsg.textContent = 'Extension not connected. Sample data not loaded.';
		}
		
		linksDiv.appendChild(noJobsMsg);
	} else {
		// Sort jobs by time (newest first)
		const sortedJobs = [...externalApplyData].sort((a, b) => {
			const timeA = a.time || 0;
			const timeB = b.time || 0;
			return timeB - timeA;
		});
		
		sortedJobs.forEach((job) => {
			addLinkRow(job);
		});
	}
	
	updateLinksCounter(externalApplyData.length);
}

// Function to load data from Chrome extension storage
function loadFromExtensionStorage() {
	if (isExtensionContext()) {
		console.log('Loading data from extension storage...');
		chrome.storage.local.get('externalApplyData', (result) => {
			if (chrome.runtime.lastError) {
				console.error('Error loading from extension storage:', chrome.runtime.lastError);
				loadSampleData();
				return;
			}
			
			externalApplyData = result.externalApplyData || [];
			console.log('Loaded data from extension:', externalApplyData.length, 'jobs');
			console.log('Loaded jobs:', externalApplyData);
			loadJobs();
		});
	} else {
		console.log('Not in extension context, loading sample data');
		loadSampleData();
	}
}

// Function to save data to Chrome extension storage
function saveToExtensionStorage() {
	if (isExtensionContext()) {
		chrome.storage.local.set({ externalApplyData: externalApplyData }, () => {
			if (chrome.runtime.lastError) {
				console.error('Error saving to extension storage:', chrome.runtime.lastError);
			} else {
				console.log('Data saved to extension storage');
			}
		});
	}
}

// Sample data for when extension is not available
function loadSampleData() {
	externalApplyData = [
		{
			title: "Senior Software Engineer",
			companyName: "Tech Corp",
			link: "https://example.com/job1",
			time: new Date().getTime() - 86400000 // 1 day ago
		},
		{
			title: "Frontend Developer",
			companyName: "StartupXYZ",
			link: "https://example.com/job2",
			time: new Date().getTime() - 172800000 // 2 days ago
		},
		{
			title: "Full Stack Developer",
			companyName: "Innovation Inc",
			link: "https://example.com/job3",
			time: new Date().getTime() - 259200000 // 3 days ago
		}
	];
	loadJobs();
}

// Function to remove a specific job
function removeJob(linkToDelete) {
	externalApplyData = externalApplyData.filter(job => job.link !== linkToDelete);
	saveToExtensionStorage();
	loadJobs();
}

// Function to remove duplicate links
function removeDuplicateLinks() {
	const uniqueLinks = new Map();
	const originalLength = externalApplyData.length;
	
	// Keep only the first occurrence of each link
	const uniqueArr = externalApplyData.filter(job => {
		if (!uniqueLinks.has(job.link)) {
			uniqueLinks.set(job.link, true);
			return true;
		}
		return false;
	});
	
	externalApplyData = uniqueArr;
	saveToExtensionStorage();
	loadJobs();
	
	const removedCount = originalLength - uniqueArr.length;
	if (removedCount > 0) {
		alert(`Removed ${removedCount} duplicate link(s)`);
	} else {
		alert('No duplicate links found');
	}
}

// Function to add new job (called by the form)
function addNewJob() {
	const title = document.getElementById('job-title').value.trim();
	const companyName = document.getElementById('company-name').value.trim();
	const link = document.getElementById('job-link').value.trim();
	
	if (!title || !companyName || !link) {
		alert('Please fill in all fields');
		return;
	}
	
	// Check if URL is valid
	try {
		new URL(link);
	} catch (e) {
		alert('Please enter a valid URL');
		return;
	}
	
	// Check for duplicates
	const isDuplicate = externalApplyData.some(job => job.link === link);
	if (isDuplicate) {
		alert('This job link already exists!');
		return;
	}
	
	// Add new job
	const newJob = {
		title: title,
		companyName: companyName,
		link: link,
		time: new Date().getTime()
	};
	
	externalApplyData.unshift(newJob); // Add to beginning of array
	saveToExtensionStorage(); // Save to extension storage
	
	// Reload the display
	loadJobs();
	
	// Clear form
	document.getElementById('job-title').value = '';
	document.getElementById('company-name').value = '';
	document.getElementById('job-link').value = '';
	
	alert('Job link added successfully!');
}

// Function to manually refresh data from extension
function refreshData() {
	console.log('Manually refreshing data from extension...');
	if (isExtensionContext()) {
		// Clear current data first
		externalApplyData = [];
		loadFromExtensionStorage();
	} else {
		loadSampleData();
	}
}

// Function to check extension connection status and debug info
function checkExtensionStatus() {
	const statusDiv = document.createElement('div');
	statusDiv.id = 'extension-status';
	statusDiv.style.cssText = `
		position: fixed;
		top: 10px;
		right: 10px;
		padding: 10px;
		border-radius: 5px;
		font-size: 12px;
		z-index: 1000;
		max-width: 300px;
	`;
	
	if (isExtensionContext()) {
		statusDiv.innerHTML = `
			🟢 Connected to Extension<br>
			<small>ZenX-AI Extension Detected</small>
		`;
		statusDiv.style.backgroundColor = '#d4edda';
		statusDiv.style.color = '#155724';
		statusDiv.style.border = '1px solid #c3e6cb';
		
		// Also check if we have data
		chrome.storage.local.get('externalApplyData', (result) => {
			const dataCount = result.externalApplyData ? result.externalApplyData.length : 0;
			statusDiv.innerHTML += `<br><small>Jobs in storage: ${dataCount}</small>`;
		});
	} else {
		statusDiv.innerHTML = `
			🔴 Extension Not Available<br>
			<small>Using Sample Data</small>
		`;
		statusDiv.style.backgroundColor = '#f8d7da';
		statusDiv.style.color = '#721c24';
		statusDiv.style.border = '1px solid #f5c6cb';
	}
	
	document.body.appendChild(statusDiv);
	
	// Remove status after 8 seconds
	setTimeout(() => {
		if (statusDiv.parentNode) {
			statusDiv.remove();
		}
	}, 8000);
}

// DOM Content Loaded Event Listener
document.addEventListener('DOMContentLoaded', () => {
	// Initialize DOM element references
	linksDiv = document.getElementById('links');
	const removeAllBtn = document.getElementById('remove-all');
	const openAllLinksBtn = document.getElementById('open-all-links');
	const removeDuplicatesBtn = document.getElementById('remove-duplicates');
	const refreshDataBtn = document.getElementById('refresh-data');
	linksCountElement = document.getElementById('links-count');
	
	// Show extension connection status
	checkExtensionStatus();
	
	// Load initial data from extension storage
	loadFromExtensionStorage();
	
	// Listen for storage changes to auto-update the display
	if (isExtensionContext()) {
		chrome.storage.onChanged.addListener((changes, namespace) => {
			if (namespace === 'local' && changes.externalApplyData) {
				console.log('Extension storage changed, reloading data');
				externalApplyData = changes.externalApplyData.newValue || [];
				loadJobs();
			}
		});
	}
	
	// Event listeners
	removeAllBtn.addEventListener('click', () => {
		if (confirm('Are you sure you want to remove all job links?')) {
			externalApplyData = [];
			saveToExtensionStorage();
			loadJobs();
		}
	});
	
	openAllLinksBtn.addEventListener('click', () => {
		if (externalApplyData.length === 0) {
			alert('No job links to open!');
			return;
		}
		
		if (confirm(`This will open ${externalApplyData.length} tabs. Continue?`)) {
			externalApplyData.forEach(job => {
				window.open(job.link, '_blank');
			});
		}
	});
	
	removeDuplicatesBtn.addEventListener('click', () => {
		removeDuplicateLinks();
	});
	
	refreshDataBtn.addEventListener('click', () => {
		refreshData();
	});
});