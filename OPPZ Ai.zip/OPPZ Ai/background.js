// Background script for OPPZ extension
// Handles notification support and extension badge updates

let currentInputFieldConfigs = [];

// Notification-related message handlers
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    try {
        // Handle notification-related actions
        if (request.action === 'openExtensionPopup') {
            // Open the extension popup
            chrome.action.openPopup().catch(error => {
                console.log('Could not open popup:', error);
                // Fallback: open extension options or popup page
                chrome.tabs.create({ url: chrome.runtime.getURL('popup/popup.html') });
            });
            sendResponse({ success: true });
            
        } else if (request.action === 'updateExtensionBadge') {
            // Update extension badge text and color
            const { text, color } = request;
            
            chrome.action.setBadgeText({ 
                text: text || '',
                tabId: sender.tab?.id 
            });
            
            chrome.action.setBadgeBackgroundColor({ 
                color: color || '#0066cc',
                tabId: sender.tab?.id 
            });
            
            sendResponse({ success: true });
            
        } else if (request.action === 'startAutoApply') {
            return handleStartAutoApply(request, sender, sendResponse);
            
        } else if (request.action === 'externalApplyAction') {
            const { jobTitle, currentPageLink, companyName } = request.data;
            saveLinkedInJobData(jobTitle, currentPageLink, companyName)
                .then(() => {
                    sendResponse({ success: true });
                }).catch(() => {
                    sendResponse({ success: false });
                });
            return true;
            
        } else if (request.action === 'openDefaultInputPage') {
            chrome.tabs.create({ url: 'popup/formControl/formControl.html' });
            
        } else if (request.action === 'stopAutoApply') {
            return handleAutoApplyStop(sender.tab?.id, sendResponse);
            
        } else if (request.action === 'checkAutoApplyStatus') {
            return checkAutoApplyStatus(sender.tab?.id, sendResponse);
            
        } else if (request.action === 'openTabAndRunScript') {
            chrome.tabs.create({ url: request.url }, (tab) => {
                chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
                    if (tabId === tab.id && changeInfo.status === 'complete') {
                        chrome.tabs.sendMessage(tabId, { action: 'showRunningModal' })
                            .then(response => {
                                if (response && response.success) {
                                    chrome.scripting.executeScript({
                                        target: { tabId: tabId },
                                        func: runScriptInContent
                                    }).then(() => {
                                        sendResponse({ success: true });
                                    }).catch(err => {
                                        console.trace('executeScript error:' + err?.message);
                                        sendResponse({ success: false, message: err.message });
                                        chrome.tabs.sendMessage(tabId, { action: 'hideRunningModal' });
                                    });
                                } else {
                                    console.trace('Failed to show running modal: ' + response?.message);
                                    sendResponse({ success: false, message: response?.message || 'Failed to show running modal.' });
                                }
                            }).catch(err => {
                                console.trace('Error sending showRunningModal: ' + err?.message);
                                sendResponse({ success: false, message: 'Failed to send showRunningModal: ' + err?.message });
                            });
                        
                        chrome.tabs.onUpdated.removeListener(listener);
                    }
                });
            });
            return true;
            
        } else if (request.action === 'updateInputFieldValue') {
            const { placeholder, value } = request.data;
            updateOrAddInputFieldValue(placeholder, value)
                .then(() => sendResponse({ success: true }))
                .catch(err => {
                    console.trace("Error in updateInputFieldValue: " + err?.message);
                    sendResponse({ success: false, message: err?.message });
                });
            return true;
            
        } else if (request.action === 'updateInputFieldConfigsInStorage') {
            const placeholder = request.data;
            updateInputFieldConfigsInStorage(placeholder)
                .then(() => sendResponse({ success: true }))
                .catch(err => {
                    console.trace('Error in updateInputFieldConfigsInStorage:' + err?.message);
                    sendResponse({ success: false, message: err?.message });
                });
            return true;
            
        } else if (request.action === 'deleteInputFieldConfig') {
            const placeholder = request.data;
            deleteInputFieldConfig(placeholder);
            
        } else if (request.action === 'getInputFieldConfig') {
            getInputFieldConfig(sendResponse);
            return true;
            
        } else if (request.action === 'updateRadioButtonValueByPlaceholder') {
            updateRadioButtonValue(request.placeholderIncludes, request.newValue);
            
        } else if (request.action === 'deleteRadioButtonConfig') {
            deleteRadioButtonConfig(request.data);
            
        } else if (request.action === 'updateDropdownConfig') {
            updateDropdownConfig(request.data);
            
        } else if (request.action === 'deleteDropdownConfig') {
            deleteDropdownValueConfig(request.data);
            
        } else if (request.action === 'logout') {
            clearAuthData();
            sendResponse({ success: true });
            
        }  else if (request.action === 'logout') {
            clearAuthData();
            sendResponse({ success: true });
            
        } else if (request.action === 'updateAuthState') {
            // Handle auth state updates
            console.log('Auth state updated');
            sendResponse({ success: true });
        
        } else {
            console.warn('Unknown action:', request.action);
            sendResponse({ success: false, message: 'Unknown action' });
        }
        
    } catch (e) {
        console.trace('onMessage error:' + e?.message);
        sendResponse({ success: false, message: e.message });
    }
});

// Handle auto-apply start
function handleStartAutoApply(request, sender, sendResponse) {
    try {
        chrome.tabs.query({ active: true, currentWindow: true })
            .then(tabs => {
                if (!tabs?.[0]) {
                    sendResponse({ success: false, message: 'No active tab found.' });
                    return;
                }
                
                const currentTabId = tabs[0].id;
                const currentUrl = tabs[0].url || request.currentUrl || '';
                
                chrome.storage.local.get('defaultFields', storageResult => {
                    if (!storageResult?.defaultFields) {
                        sendResponse({ success: false, message: 'Default fields are not set.' });
                        return;
                    }
                    
                    const result = storageResult.defaultFields;
                    const isDefaultFieldsEmpty = Object.values(result).some(value => value === '');
                    
                    if (!currentUrl.includes('linkedin.com/jobs')) {
                        chrome.tabs.sendMessage(currentTabId, { action: 'showNotOnJobSearchAlert' })
                            .then(() => sendResponse({
                                success: false,
                                message: 'You are not on the LinkedIn jobs search page.'
                            }))
                            .catch(err => {
                                const errorMessage = err?.message || 'Unknown error';
                                if (errorMessage.includes('establish connection')) return;
                                console.error('background script error:', errorMessage);
                                sendResponse({
                                    success: false,
                                    message: 'Error showing alert: ' + err.message
                                });
                            });
                        return;
                    }
                    
                    if (isDefaultFieldsEmpty) {
                        chrome.tabs.sendMessage(currentTabId, { action: 'showFormControlAlert' })
                            .then(() => sendResponse({
                                success: false,
                                message: 'Form control fields are empty. Please set them in the extension options.'
                            }))
                            .catch(err => {
                                console.trace('Error sending showFormControlAlert: ' + err?.message);
                                sendResponse({ success: false, message: 'Error showing form control alert: ' + err.message });
                            });
                        return;
                    }
                    
                    if (currentUrl.includes('linkedin.com/jobs') && !isDefaultFieldsEmpty) {
                        chrome.scripting.executeScript({
                            target: { tabId: currentTabId },
                            func: runScriptInContent
                        }).then(() => {
                            sendResponse({ success: true });
                        }).catch(err => {
                            console.trace('startAutoApply Error: ' + err?.message);
                            sendResponse({ success: false, message: err.message });
                        });
                    }
                });
            });
        return true;
    } catch (err) {
        console.trace('startAutoApply Error: ' + err?.message);
        sendResponse({ success: false, message: err.message });
        return true;
    }
}

// Handle auto-apply stop
function handleAutoApplyStop(tabId, sendResponse) {
    chrome.storage.local.set({ 'autoApplyRunning': false }, () => {
        if (!tabId) {
            sendResponse({ success: false, message: 'No tab ID provided.' });
            return;
        }
        
        chrome.tabs.get(tabId, (tab) => {
            if (chrome.runtime.lastError) {
                console.trace('Error getting tab info:' + chrome?.runtime?.lastError?.message);
                sendResponse({ success: false, message: 'Tab error: ' + chrome.runtime.lastError.message });
                return;
            }
            
            if (!tab || !tab.url || !tab.url.includes('linkedin.com/jobs')) {
                console.trace('Tab is invalid or URL does not match.');
                sendResponse({ success: false, message: 'Tab is invalid or not a LinkedIn jobs page.' });
                return;
            }
            
            chrome.tabs.sendMessage(tabId, { action: 'hideRunningModal' })
                .then(response => {
                    if (response && response.success) {
                        sendResponse({ success: true });
                    } else {
                        sendResponse({ success: false, message: 'Failed to hide modal on stop.' });
                    }
                }).catch(err => {
                    console.trace('Error sending hideRunningModal: ' + err?.message);
                    sendResponse({ success: false, message: 'Failed to send hideRunningModal: ' + err?.message });
                });
        });
    });
    return true;
}

// Check auto-apply status
function checkAutoApplyStatus(tabId, sendResponse) {
    if (tabId) {
        chrome.tabs.sendMessage(tabId, { action: 'checkScriptRunning' })
            .then(response => {
                const isActuallyRunning = response?.isRunning || false;
                chrome.storage.local.set({ autoApplyRunning: isActuallyRunning }, () => {
                    sendResponse({ isRunning: isActuallyRunning });
                });
            })
            .catch(() => {
                chrome.storage.local.set({ autoApplyRunning: false }, () => {
                    sendResponse({ isRunning: false });
                });
            });
    } else {
        chrome.storage.local.get('autoApplyRunning', ({ autoApplyRunning }) => {
            sendResponse({ isRunning: Boolean(autoApplyRunning) });
        });
    }
    return true;
}

// Utility functions for data management
async function saveLinkedInJobData(jobTitle, jobLink, companyName) {
    const storageResult = await chrome.storage.local.get('externalApplyData');
    const storedData = storageResult?.externalApplyData || [];
    storedData.push({ title: jobTitle, link: jobLink, companyName, time: Date.now() });
    
    const uniqData = [];
    const seenLinks = new Set();
    const seenTitleAndCompany = new Set();
    
    for (const item of storedData) {
        const uniqKeyLink = `${item.link}`;
        const uniqKeyTitleName = `${item.title}-${item.companyName}`;
        
        if (!seenLinks.has(uniqKeyLink) && !seenTitleAndCompany.has(uniqKeyTitleName)) {
            seenLinks.add(uniqKeyLink);
            seenTitleAndCompany.add(uniqKeyTitleName);
            uniqData.push(item);
        }
    }
    
    const sortedData = uniqData.sort((a, b) => b.time - a.time);
    await chrome.storage.local.set({ 'externalApplyData': sortedData });
}

// Input field configuration functions
function deleteInputFieldConfig(placeholder) {
    chrome.storage.local.get(['inputFieldConfigs'], result => {
        const inputFieldConfigs = result?.inputFieldConfigs || [];
        const configIndex = inputFieldConfigs.findIndex(config => config.placeholderIncludes === placeholder);
        if (configIndex !== -1) {
            inputFieldConfigs.splice(configIndex, 1);
            chrome.storage.local.set({ 'inputFieldConfigs': inputFieldConfigs }, () => {
                currentInputFieldConfigs = inputFieldConfigs;
            });
        }
    });
}

async function updateOrAddInputFieldValue(placeholder, value) {
    try {
        const { inputFieldConfigs = [] } = await chrome.storage.local.get('inputFieldConfigs');
        const foundConfig = inputFieldConfigs.find(config => config.placeholderIncludes === placeholder);
        
        if (foundConfig) {
            foundConfig.defaultValue = value;
        } else {
            const newConfig = { placeholderIncludes: placeholder, defaultValue: value, count: 1 };
            inputFieldConfigs.push(newConfig);
        }
        
        await chrome.storage.local.set({ inputFieldConfigs });
        
    } catch (error) {
        console.trace("Error updating or adding input field value:" + error?.message);
        throw error;
    }
}

async function updateInputFieldConfigsInStorage(placeholder) {
    try {
        const result = await chrome.storage.local.get('inputFieldConfigs');
        const inputFieldConfigs = result?.inputFieldConfigs || [];
        const foundConfig = inputFieldConfigs.find(config => config.placeholderIncludes === placeholder);
        
        if (foundConfig) {
            foundConfig.count++;
            if (!('createdAt' in foundConfig) || !foundConfig.createdAt) {
                foundConfig.createdAt = Date.now();
            }
        } else {
            const newConfig = { placeholderIncludes: placeholder, defaultValue: '', count: 1, createdAt: Date.now() };
            inputFieldConfigs.push(newConfig);
        }
        
        chrome.storage.local.set({ 'inputFieldConfigs': inputFieldConfigs }, () => {
            currentInputFieldConfigs = inputFieldConfigs;
        });
    } catch (error) {
        console.trace('Error updating input field configs: ' + error?.message);
        throw error;
    }
}

function getInputFieldConfig(callback) {
    try {
        chrome.storage.local.get(['inputFieldConfigs'], result => {
            const fieldConfig = result && result?.inputFieldConfigs ? result?.inputFieldConfigs : null;
            callback(fieldConfig);
        });
    } catch (error) {
        callback(null);
    }
}

// Radio button configuration functions
function updateRadioButtonValue(placeholderIncludes, newValue) {
    chrome.storage.local.get('radioButtons', (result) => {
        const storedRadioButtons = result.radioButtons || [];
        const storedRadioButtonInfo = storedRadioButtons.find(info => info.placeholderIncludes === placeholderIncludes);
        if (storedRadioButtonInfo) {
            storedRadioButtonInfo.defaultValue = newValue;
            storedRadioButtonInfo.options.forEach(option => {
                option.selected = option.value === newValue;
            });
            chrome.storage.local.set({ 'radioButtons': storedRadioButtons });
        } else {
            console.trace(`Item with placeholderIncludes ${placeholderIncludes} not found`);
        }
    });
}

function deleteRadioButtonConfig(placeholder) {
    chrome.storage.local.get('radioButtons', function(result) {
        const radioButtons = result.radioButtons || [];
        const updatedRadioButtons = radioButtons.filter(config => config.placeholderIncludes !== placeholder);
        chrome.storage.local.set({ 'radioButtons': updatedRadioButtons });
    });
}

// Dropdown configuration functions
function updateDropdownConfig(dropdownData) {
    if (!dropdownData || !dropdownData.placeholderIncludes || !dropdownData.value || !dropdownData.options) {
        return;
    }
    
    chrome.storage.local.get('dropdowns', function(result) {
        let dropdowns = result.dropdowns || [];
        const storedDropdownInfo = dropdowns.find(info => info.placeholderIncludes === dropdownData.placeholderIncludes);
        
        if (storedDropdownInfo) {
            storedDropdownInfo.value = dropdownData.value;
            storedDropdownInfo.options = dropdownData.options.map(option => ({
                value: option.value,
                text: option.text || '',
                selected: option.value === dropdownData.value
            }));
            
            if (!('createdAt' in storedDropdownInfo) || !storedDropdownInfo.createdAt) {
                storedDropdownInfo.createdAt = Date.now();
            }
        } else {
            dropdowns.push({
                placeholderIncludes: dropdownData.placeholderIncludes,
                value: dropdownData.value,
                createdAt: Date.now(),
                options: dropdownData.options.map(option => ({
                    value: option.value,
                    text: option.text || '',
                    selected: option.value === dropdownData.value
                }))
            });
        }
        chrome.storage.local.set({ dropdowns });
    });
}

function deleteDropdownValueConfig(placeholder) {
    chrome.storage.local.get('dropdowns', function(result) {
        let dropdowns = result.dropdowns || [];
        const indexToDelete = dropdowns.findIndex(config => config.placeholderIncludes === placeholder);
        if (indexToDelete !== -1) {
            dropdowns.splice(indexToDelete, 1);
            chrome.storage.local.set({ 'dropdowns': dropdowns });
        }
    });
}

// Authentication functions
function clearAuthData() {
    chrome.storage.local.remove(['authToken', 'userEmail'], () => {
        console.log('Auth data cleared');
    });
}

// Content script execution function
function runScriptInContent() {
    if (typeof runScript === 'function') {
        runScript();
    }
}

// Extension installation/startup handler
chrome.runtime.onInstalled.addListener(() => {
    console.log('OPPZ Extension installed/updated');
    
    // Set default badge
    chrome.action.setBadgeText({ text: '' });
    chrome.action.setBadgeBackgroundColor({ color: '#0066cc' });
});

// Tab update listener for notification updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.includes('linkedin.com')) {
        // Reset badge when navigating on LinkedIn
        chrome.action.setBadgeText({ text: '', tabId: tabId });
    }
});

// Handle extension icon clicks
chrome.action.onClicked.addListener((tab) => {
    // This will be handled by the popup, but kept for fallback
    console.log('Extension icon clicked');
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.from === 'website' && message.action === 'getFormControlData') {
    chrome.storage.local.get(['inputFieldConfigs', 'radioButtons', 'dropdowns'], (data) => {
      sendResponse({ success: true, data });
    });
    return true; // Important: keeps the response channel open
  }
});

// External website messaging handler
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  const { from, action, data } = message;
  if (from !== 'website') return;

  // 1. READ all form control data
  if (action === 'getFormControlData') {
    chrome.storage.local.get(['inputFieldConfigs', 'radioButtons', 'dropdowns'], (result) => {
      sendResponse({ success: true, data: result });
    });
    return true;
  }

  // 2. UPDATE input text field value
  if (action === 'updateInputFieldValue') {
    chrome.storage.local.get(['inputFieldConfigs'], (result) => {
      const configs = result.inputFieldConfigs || [];
      const updated = configs.map(config =>
        config.placeholderIncludes === data.placeholder
          ? { ...config, defaultValue: data.value }
          : config
      );
      chrome.storage.local.set({ inputFieldConfigs: updated }, () => {
        sendResponse({ success: true });
      });
    });
    return true;
  }

  // 3. UPDATE radio button value
  if (action === 'updateRadioButtonValue') {
    chrome.storage.local.get(['radioButtons'], (result) => {
      const configs = result.radioButtons || [];
      const updated = configs.map(config =>
        config.placeholderIncludes === data.placeholder
          ? {
              ...config,
              options: config.options.map(option => ({
                ...option,
                selected: option.value === data.value
              }))
            }
          : config
      );
      chrome.storage.local.set({ radioButtons: updated }, () => {
        sendResponse({ success: true });
      });
    });
    return true;
  }

  // 4. UPDATE dropdown selected value
  if (action === 'updateDropdownValue') {
    chrome.storage.local.get(['dropdowns'], (result) => {
      const configs = result.dropdowns || [];
      const updated = configs.map(config =>
        config.placeholderIncludes === data.placeholder
          ? {
              ...config,
              options: config.options.map(option => ({
                ...option,
                selected: option.value === data.selectedValue
              }))
            }
          : config
      );
      chrome.storage.local.set({ dropdowns: updated }, () => {
        sendResponse({ success: true });
      });
    });
    return true;
  }
});
